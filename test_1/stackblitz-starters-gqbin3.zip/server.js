const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

// Middleware to check for a valid token
const TOKEN = 'your-secret-token'; // Replace this with your actual token

function tokenMiddleware(req, res, next) {
    const token = req.headers['authorization'];
    console.log(req.headers)

    if (token && token === `Bearer ${token}`) {
        next(); // Token is valid, proceed to the next middleware/route handler
    } else {
        res.status(403).send('Forbidden: Invalid token');
    }
}


// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve static files (like HTML and CSS)
app.use(express.static(path.join(__dirname, 'public')));

// Set the view engine to ejs and specify the views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.get('/', (req, res) => {
  res.render('index')
});

// Database setup
const db = new sqlite3.Database('./database.db');

// Handle form submission
app.post('/contact', (req, res) => {
    const { name, email, message } = req.body;

    // Insert form data into the database
    db.run('INSERT INTO contact (name, email, message) VALUES (?, ?, ?)', [name, email, message], function(err) {
        if (err) {
            console.error('Error inserting data:', err);
            res.status(500).send('Internal Server Error');
        } else {
            console.log('Data inserted successfully');
            res.send('Form submitted successfully!');
        }
    });
});


// Use the token verification middleware for this route
app.get('/api/contact', tokenMiddleware, (req, res) => {
  console.log('hi')
  db.all('SELECT * FROM contact', [], (err, rows) => {
      if (err) {
          console.error('Error retrieving data:', err);
          res.status(500).send('Internal Server Error');
      } else {
          res.json(rows); // Send data as JSON response
      }
  });
});




app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
