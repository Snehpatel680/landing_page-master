document.addEventListener('DOMContentLoaded', () => {
  const testimonials = document.querySelectorAll('.testimonial-item');
  let currentIndex = 0;

  function showTestimonial(index) {
    testimonials.forEach((item, i) => {
      item.classList.toggle('active', i === index);
    });
  }

  function showNext() {
    currentIndex = (currentIndex + 1) % testimonials.length;
    showTestimonial(currentIndex);
  }

  showTestimonial(currentIndex);

  // Auto-slide every 3 seconds
  setInterval(showNext, 3000);

  const form = document.getElementById('contactForm');
  const responseMessage = document.getElementById('responseMessage');

  form.addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(form);

    try {
      const response = await fetch('/contact', {
        method: 'POST',
        body: new URLSearchParams(formData),
      });

      if (response.ok) {
        responseMessage.textContent = 'Form submitted successfully!';
      } else {
        responseMessage.textContent =
          'Form submission failed. Please try again.';
      }
    } catch (error) {
      console.error('Error:', error);
      responseMessage.textContent = 'An error occurred. Please try again.';
    }

    const response = await fetch('/api/contact', {
      method: 'GET',
      headers: {
        authorization: 'your-secret-token',
      },
    });

    console.log(response);
  });
});
